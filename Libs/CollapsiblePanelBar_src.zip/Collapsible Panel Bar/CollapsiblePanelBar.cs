using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Salamander.Windows.Forms
{
	#region CollapsiblePanelBar class
	// <fix>Implemented System.ComponentModel.ISupportInitialize interface to fix run-time/design-time ordering problem.
	// <version>1.2</version>
	// </date>21-Oct-2002</date>
	// <source>Russell Morris (mailto:russell@russellsprojects.com)
	// </fix>
	/// <summary>
	/// An ExplorerBar-type extended Panel for containing <see cref="CollapsiblePanel">CollapsiblePanel</see> objects.
	/// </summary>
	public class CollapsiblePanelBar : System.Windows.Forms.Panel, System.ComponentModel.ISupportInitialize
	{
		#region Private class data
		private CollapsiblePanelCollection panels = new CollapsiblePanelCollection();
		private int border = 8;
		private int spacing = 8;
		private bool initialising = false;
		#endregion

		#region Public Constructors
		/// <summary>
		/// Initialises a new instance of <see cref="Salamander.Windows.Forms.CollapsiblePanelBar">CollapsiblePanelBar</see>.
		/// </summary>
		public CollapsiblePanelBar() : base()
		{
			InitializeComponent();

			this.BackColor = Color.CornflowerBlue;
		}
		#endregion

		#region Windows Form Designer generated code
		private void InitializeComponent()
		{
			// 
			// CollapsiblePanelBar
			// 
		}
		#endregion

		#region Public Properties
		/// <summary>
		/// Gets the <see cref="CollapsiblePanelCollection">CollapsiblePanelCollection</see> collection.
		/// </summary>
		[Browsable(false)]
		public CollapsiblePanelCollection CollapsiblePanelCollection
		{
			get
			{
				return this.panels;
			}
		}

		/// <summary>
		/// Gets/sets the border around the panels. 
		/// </summary>
		public int Border
		{
			get
			{
				return this.border;
			}
			set
			{
				this.border = value;
				UpdatePositions(this.panels.Count - 1);
			}
		}

		/// <summary>
		/// Gets/sets the vertical spacing between adjacent panels.
		/// </summary>
		public int Spacing
		{
			get
			{
				return this.spacing;
			}
			set
			{
				this.spacing = value;
				UpdatePositions(this.panels.Count - 1);
			}
		}
		#endregion

		#region Public Methods
		/// <summary>
		/// Signals the object that initialization is starting.
		/// </summary>
		public void BeginInit()
		{
			this.initialising = true;
		}

		/// <summary>
		/// Signals the object that initialization is complete.
		/// </summary>
		public void EndInit()
		{
			this.initialising = false;
		}
		#endregion
		
		#region Private Helper Functions
		private void UpdatePositions(int index)
		{
			for(int i = index; i >= 0; i--)
			{
				// Update the panel locations.
				if(i == this.panels.Count - 1)
				{
					// Top panel.
					this.panels.Item(i).Top = this.border;
				}
				else
				{
					this.panels.Item(i).Top = this.panels.Item(i + 1).Bottom + this.border;
				}
				// Update the panel widths.
				this.panels.Item(i).Left = this.spacing;
				this.panels.Item(i).Width = this.Width - (2 * this.spacing);
				// <feature>Panel width adjusted when vertical scroll bars are present.
				// <version>1.3</version>
				// <date>23-Oct-2002</date>
				if(true == this.VScroll)
				{
					this.panels.Item(i).Width -= SystemInformation.VerticalScrollBarWidth;
				}
				// </feature>
			}
		}
		#endregion

		#region Protected Methods
		/// <summary>
		/// Event handler for the <see cref="Control.ControlAdded">ControlAdded</see> event.
		/// </summary>
		/// <param name="e">A <see cref="System.Windows.Forms.ControlEventArgs">ControlEventArgs</see> that contains the event data.</param>
		protected override void OnControlAdded(ControlEventArgs e)
		{
			base.OnControlAdded(e);

            // <fix>Changed type check to allow for derived CollapsiblePanels
            // <version>1.4</version>
            // <date>19-Dec-2002</date>
            // <source>flipdoubt (mailto:d.smith@ceoimage.com)
			if(e.Control is CollapsiblePanel)
            // </fix>
			{
				// Adjust the docking property to Left | Right | Top
				e.Control.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right;

				// <fix>Implemented System.ComponentModel.ISupportInitialize interface to fix run-time/design-time ordering problem.
				// <version>1.2</version>
				// </date>21-Oct-2002</date>
				// <source>Russell Morris (mailto:russell@russellsprojects.com)
				if(true == initialising)
				{
					// In the middle of InitializeComponent call.
					// Generated code adds panels in reverse order, so add to end
					this.panels.Add((CollapsiblePanel)e.Control);

					this.panels.Item(this.panels.Count - 1).PanelStateChanged +=
						new Salamander.Windows.Forms.PanelStateChangedEventHandler(this.panel_StateChanged);
				}
				else
				{
					// Add the panel to the beginning of the internal collection.
					panels.Insert(0, (CollapsiblePanel)e.Control);

					panels.Item(0).PanelStateChanged += 
						new Salamander.Windows.Forms.PanelStateChangedEventHandler(this.panel_StateChanged);
				}
				// </fix>

				// Update the size and position of the panels
				UpdatePositions(this.panels.Count - 1);
			}
		}

		/// <summary>
		/// Event handler for the <see cref="Control.ControlRemoved">ControlRemoved</see> event.
		/// </summary>
		/// <param name="e">A <see cref="System.Windows.Forms.ControlEventArgs">ControlEventArgs</see> that contains the event data.</param>
		protected override void OnControlRemoved(ControlEventArgs e)
		{
			base.OnControlRemoved(e);

            // <fix>Changed type check to allow for derived CollapsiblePanels
            // <version>1.4</version>
            // <date>19-Dec-2002</date>
            // <source>flipdoubt (mailto:d.smith@ceoimage.com)
            if(e.Control is CollapsiblePanel)
            // </fix>
            {
				// Get the index of the panel within the collection.
				int index = this.panels.IndexOf((CollapsiblePanel)e.Control);
				if(-1 != index)
				{
					// Remove this panel from the collection.
					this.panels.Remove(index);
					// Update the position of any remaining panels.
					UpdatePositions(this.panels.Count - 1);
				}
			}
		}
		#endregion

		#region Event handlers
		private void panel_StateChanged(object sender, PanelEventArgs e)
		{
			// Get the index of the control that just changed state.
			int index = this.panels.IndexOf(e.CollapsiblePanel);
			if(-1 != index)
			{
				// Now update the position of all subsequent panels.
				UpdatePositions(--index);
			}
		}
		#endregion
	}
	#endregion
}
